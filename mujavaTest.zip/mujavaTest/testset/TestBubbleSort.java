import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
public class TestBubbleSort {
	private BubbleSort b;
	@Before
	public void setup() throws Exception{
		b = new BubbleSort();
	}
	
	@After 
	public void down() throws Exception{
		b = null;
	}
	@Test
	public void SortTest() {
		assertEquals("[1, 2, 3, 4, 5]",Arrays.toString(BubbleSort.BubbleSort(new int[]{3,1,2,5,4})));
		assertEquals("[1, 2, 3, 4, 5, 6, 7]",Arrays.toString(BubbleSort.BubbleSort(new int[]{7,3,2,4,1,6,5})));
	}
}
